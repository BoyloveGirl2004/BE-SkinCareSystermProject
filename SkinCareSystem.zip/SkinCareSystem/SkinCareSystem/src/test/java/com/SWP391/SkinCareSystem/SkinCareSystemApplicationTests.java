package com.SWP391.SkinCareSystem;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SkinCareSystemApplicationTests {

	@Test
	void contextLoads() {
	}

}
