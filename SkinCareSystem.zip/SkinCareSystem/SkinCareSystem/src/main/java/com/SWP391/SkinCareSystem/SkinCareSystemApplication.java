package com.SWP391.SkinCareSystem;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SkinCareSystemApplication {

	public static void main(String[] args) {
		SpringApplication.run(SkinCareSystemApplication.class, args);
	}

}
